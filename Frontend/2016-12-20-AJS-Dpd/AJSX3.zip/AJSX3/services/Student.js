/**
 * Created by itzhaksavion on 19/12/2016.
 */
angular.module("classPlan").
constant("studentUrl", "http://localhost:5600/plan").
factory('Student', ['$http', function($http) {

    return {
        getStudents:function(xsuccess,xerror) {
            $http.get("http://localhost:5600/students")
                .success(function(data)
                {
                    xsuccess(data);
                })
                .error(function(err){
                   console.log(err);
                   xerror(err);
                });
        }
    }
}]);