angular.module("classPlan").
controller('classProfCtrl', ['$rootScope',
    '$location',
    '$scope',
    '$routeParams',
    'Plan',
    function ($rootScope,
              $location,
              $scope,
              $routeParams,
              Plan)
    {
        $scope.title="This is Siftach";

    }]);
