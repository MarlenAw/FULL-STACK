angular.module("classPlan").
controller('classStudentCtrl', ['$rootScope',
    '$location',
    '$scope',
    '$routeParams',
    'Student',
    function ($rootScope,
              $location,
              $scope,
              $routeParams,
              Student)
    {
        $scope.title="This is one Student id="+$routeParams.id;

        Student.getStudents(function(data){
            $scope.studentsdata=data;

        }, function(error){
            console.log(error);
        })



    }]);
