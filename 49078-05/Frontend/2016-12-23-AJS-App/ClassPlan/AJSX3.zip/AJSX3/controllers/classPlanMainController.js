angular.module("classPlan").
controller('classPlanMainCtrl',
    function ($scope,
              Plan)
    {
        $scope.title="TEST TEXT 1";
        Plan.getPlan(function(data){
            $scope.data=data;
        },function(error){

        });

        $scope.saveData= function()
        {


        }

    });