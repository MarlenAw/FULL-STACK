angular.module("classPlan").
    controller('classPlanCtrl',
    function ($scope,
              Plan)
        {
        $scope.naturalState=true;
        $scope.title="TEST TEXT 2";

            Plan.getPlan(function(datax){
                console.log(datax);
                datax.sort(function(a,b){
                    if (a.row<b.row)
                    {
                        return -1;
                    }
                    else if (a.row>b.row)
                    {
                        return 1;
                    }
                    else
                    {
                        if (a.col<b.col)
                        {
                            return -1;
                        }
                        else  if (a.col>b.col)
                        {
                            return 1;
                        }
                        else
                        {
                            return 0;
                        }
                    }
                });
                console.log(datax);
                $scope.data=[];

                // Initilize Array
                for(var i=0;i<4;i++)
                {
                    $scope.data.push(new Array());
                    for(var j=0;j<5;j++)
                    {
                        var c={};

                        c.id=0;
                        c.row=i;
                        c.col=j;
                        c.Name="";
                        $scope.data[i].push(c);
                    }
                }



                for(var i=0;i<datax.length;i++)
                {
                    var currObj=datax[i];
                    $scope.data[currObj.row][currObj.col]=currObj;
                }



                console.log("Sorted");
                console.log($scope.data);

            },function(error){

            });

            $scope.revertData= function()
            {
                if($scope.isProfView==true) {

                    for (var i = 0; i < $scope.data.length; i++) {
                        var newArr = new Array();
                        for (var j = $scope.data[i].length - 1; j >= 0; j--) {
                            newArr.push($scope.data[i][j]);
                        }
                        $scope.data[i] = newArr;
                    }
                    $scope.naturalState=false;
                }
                else
                {
                    for (var i = 0; i < $scope.data.length; i++) {
                        var newArr = new Array();
                        for (var j = 0;j<$scope.data[i].length; j++) {
                            newArr.push($scope.data[i][j]);
                        }
                        $scope.data[i] = newArr;
                    }
                    $scope.naturalState=true;
                }
            }
            $scope.saveData= function()
            {
                for(var i=0;i<$scope.data.length;i++)
                {
                    for(var j=0;j<$scope.data[i].length;j++)
                    {
                        if (($scope.data[i][j].id==0)&&
                            ($scope.data[i][j].Name!=''))
                        {
                            Plan.addPlan($scope.data[i][j],
                                function () {
                                }, function (err) {
                                    console.log("err Add");
                                    console.log(err);
                                });
                        }
                        else {
                            if ($scope.data[i][j].id!=0) {

                                Plan.savePlan($scope.data[i][j],
                                    function () {
                                    }, function (err) {
                                        console.log("err Save");
                                        console.log(err);
                                    });
                            }
                            else
                            {

                                if ($scope.data[i][j].Name!='') {
                                    Plan.deletePlan($scope.data[i][j],
                                        function () {
                                        }, function (err) {
                                            console.log("err Save");
                                            console.log(err);
                                        });
                                }

                            }
                        }
                    }
                }
            }
});