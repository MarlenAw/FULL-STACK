/**
 * Created by itzhaksavion on 11/12/2016.
 */
angular.module("classPlan").
 constant("planUrl", "http://localhost:5600/plan").
 factory('Plan', ['$http', function($http){

     return {
         getPlan: function(xsuccess,xerror)
         {
             $http.get("http://localhost:5600/plan")
                 .success(function (data) {
                     xsuccess(data);
                 })
                 .error(function (error) {
                     xerror(error);
                 })
             return;
         },
         savePlan: function(newPlan,xsuccess,xerror)
         {
             $http.put("http://localhost:5600/plan",newPlan)
                 .success(function (data) {
                     xsuccess(data);
                 })
                 .error(function (error) {
                     xerror(error);
                 });
         },
         addPlan: function(newPlan,xsuccess,xerror)
         {
             $http.post("http://localhost:5600/plan",newPlan)
                 .success(function (data) {
                     xsuccess(data);
                 })
                 .error(function (error) {
                     xerror(error);
                 });
         },
         deletePlan: function(oldPlan,xsuccess,xerror)
         {
             $http.delete("http://localhost:5600/plan/"+oldPlan.id,oldPlan)
                 .success(function (data) {
                     xsuccess(data);
                 })
                 .error(function (error) {
                     xerror(error);
                 });
         }


     }

 }]);
