/**
 * Created by itzhaksavion on 19/12/2016.
 */
angular.module("classPlan").
constant("studentUrl", "http://localhost:5600/plan").
factory('Student', ['$http', function($http) {

    return {
        getStudents:function(xsuccess,xerror) {
            $http.get("http://localhost:5600/students")
                .success(function(data)
                {
                    xsuccess(data);
                })
                .error(function(err){
                   console.log(err);
                   xerror(err);
                });
        },

        saveStudent:function(student,xsuccess,xerror) {
            $http.put("http://localhost:5600/students/"+student.id,student)
                .success(function(data)
                {
                    xsuccess(data);
                })
                .error(function(err){
                    console.log(err);
                    xerror(err);
                });
        },

        addStudent:function(student,xsuccess,xerror) {
            console.log("AddStudent");
            console.log(student);
            $http.post("http://localhost:5600/students",student)
                .success(function(data)
                {
                    xsuccess(data);
                })
                .error(function(err){
                    console.log(err);
                    xerror(err);
                });
        },
        deleteStudent:function(student,xsuccess,xerror) {
            console.log("deleteStudent");
            console.log(student);
            $http.delete("http://localhost:5600/students/"+student.id,student)
                .success(function(data)
                {
                    xsuccess(data);
                })
                .error(function(err){
                    console.log(err);
                    xerror(err);
                });
        }

    }
}]);