angular.module("classPlan").
    controller('classPlanCtrl',
    function ($scope,
              Plan)
        {
        $scope.title="TEST TEXT 2";

            Plan.getPlan(function(datax){
                console.log(datax);
                datax.sort(function(a,b){
                    if (a.row<b.row)
                    {
                        return -1;
                    }
                    else if (a.row>b.row)
                    {
                        return 1;
                    }
                    else
                    {
                        if (a.col<b.col)
                        {
                            return -1;
                        }
                        else  if (a.col>b.col)
                        {
                            return 1;
                        }
                        else
                        {
                            return 0;
                        }
                    }
                });
                console.log(datax);
                $scope.data=[];
                var currRow=0;
                $scope.data.push(new Array());
                for(var i=0;i<datax.length;i++)
                {
                    if (datax[i].row!=currRow)
                    {
                        currRow=datax[i].row;
                        $scope.data.push(new Array());
                    }
                    $scope.data[currRow].push(datax[i]);
                }
                console.log("Sorted");
                console.log($scope.data);

            },function(error){

            });

            $scope.saveData= function()
            {
                for(var i=0;i<$scope.data.length;i++)
                {
                    for(var j=0;j<$scope.data[i].length;j++)
                    {
                        Plan.savePlan($scope.data[i][j],
                            function(){
                            },function(err) {
                                console.log("err");
                                console.log(err);
                            });
                    }
                }
            }
});