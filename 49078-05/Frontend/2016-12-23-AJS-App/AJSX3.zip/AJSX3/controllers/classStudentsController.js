angular.module("classPlan").
controller('classStudentsCtrl', ['$rootScope',
    '$location',
    '$scope',
    '$routeParams',
    'Student',
    function ($rootScope,
              $location,
              $scope,
              $routeParams,
              Student)
    {
        $scope.title="This is Students";
        $scope.fname="";
        $scope.lname="";

        Student.getStudents(function(data){
            $scope.studentsdata=data;

        }, function(error){
            console.log(error);
        });


        $scope.addStudent=function()
        {
            var student={};

            student.FirstName=$scope.fname;
            student.LastName=$scope.lname;

            Student.addStudent(student,function(){},function(){});

            Student.getStudents(function(data){
                $scope.studentsdata=data;

            }, function(error){
                console.log(error);
            })

            $scope.fname="";
            $scope.lname="";

        }

        $scope.deleteStudent=function(student)
        {
            Student.deleteStudent(student,function(){},function(){});

            Student.getStudents(function(data){
                $scope.studentsdata=data;

            }, function(error){
                console.log(error);
            })
        }

    }]);
